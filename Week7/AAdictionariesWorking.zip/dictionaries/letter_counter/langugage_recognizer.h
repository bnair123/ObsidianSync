//
// Created by Dawid Zalewski on 06/12/2020.
//

#ifndef WORDS_COUNTING_LANGUGAGERECOGNIZER_H
#define WORDS_COUNTING_LANGUGAGERECOGNIZER_H



extern const char* match_language(const char* signature);

#endif //WORDS_COUNTING_LANGUGAGERECOGNIZER_H
