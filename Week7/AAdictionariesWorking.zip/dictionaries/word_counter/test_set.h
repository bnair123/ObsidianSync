#ifndef DICTIONARIES_TEST_SET_H
#define DICTIONARIES_TEST_SET_H

void test_set_add(void);
void test_set_remove(void);
void test_set_contains(void);

#endif //DICTIONARIES_TEST_SET_H
