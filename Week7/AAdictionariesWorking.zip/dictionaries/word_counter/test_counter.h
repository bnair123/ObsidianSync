//
// Created by rgr24 on 01/03/2023.
//

#ifndef DICTIONARIES_TEST_COUNTER_H
#define DICTIONARIES_TEST_COUNTER_H

void test_counter_init(void);
void test_counter_get_count(void);
void test_counter_increment(void);
void test_counter_get_pair_at(void);

#endif //DICTIONARIES_TEST_COUNTER_H
