#include "set.h"
#include "test_set.h"
#include <malloc.h>

void set_add(set_t *set, double value) {
    if (!ensure_capacity(set)) return;

    // Check if the value is already present in the set.
    bool is_present = false;
    for (size_t i = 0; i < set->count; i++) {
        if (set->eq_fun(set->data[i], value)) {
            is_present = true;
            break;
        }
    }

    if (!is_present) {
        set->data[set->count] = value;
        set->count++;
    }
}

void set_remove(set_t *set, double value) {
    size_t index = -1;
    for (size_t i = 0; i < set->count; i++) {
        if (set->eq_fun(set->data[i], value)) {
            index = i;
            break;
        }
    }

    if (index == -1) return;

    for (size_t i = index + 1; i < set->count; i++) {
        set->data[i - 1] = set->data[i];
    }

    set->count--;
}

bool set_contains(const set_t *set, double value) {
    for (size_t i = 0; i < set->count; i++) {
        if (set->eq_fun(set->data[i], value)) {
            return true;
        }
    }
    return false;
}

set_t * set_create(size_t init_cap, eq_fun_t fun) {
    return set_init((set_t*) malloc(sizeof(set_t)), init_cap, fun);
}

set_t * set_init(set_t * set, size_t init_cap, eq_fun_t fun) {
    if (set != NULL) {
        set->eq_fun = fun;
        set->data = (double*) malloc(sizeof(double) * init_cap);
        set->count = 0;
        set->capacity = set->data != NULL ? init_cap : 0;
    }
    return set;
}

bool ensure_capacity(set_t * set) {
    if (set->count < set->capacity) return true;
    size_t cap = (set->capacity + 1) * 3 / 2;
    double * ptr = realloc(set->data, cap * sizeof(double));
    if (ptr != NULL) {
        set->data = ptr;
        set->capacity = cap;
        return true;
    }
    else return false;
}

void set_destroy(set_t * set) {
    free(set->data);
    set->data = NULL;
    set->capacity = 0;
}