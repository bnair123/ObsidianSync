#include <stdio.h>
#include <math.h>
#include "set.h"
#include "test_set.h"

// global var to keep track of nr. of comparisons in binary search (activity 8)
extern size_t g_comparisons;

int cmp_dbl(double d1, double d2) {
    if (fabs(d1 - d2) < 0.00000001) {
        return 0;
    }

    // If the first value is smaller than the second, return -1.
    if (d1 < d2) {
        return -1;
    }

    // If the first value is greater than the second, return 1.
    return 1;
}


int main(void) {
    // Part 2 - a set using a sorted array

    // Activity 6
    // TODO: implement function cmp_dbl
/*    const double a = 41.0 + 0.5 + 0.2 + 0.2 + 0.1;
    const double b = 43.0 - 0.5 - 0.2 - 0.2 - 0.1;
    const double pi_1 = 3.14159265;
    const double pi_2 = 355.0 / 113.0;*/
/*
    printf("compare(%lf, %lf) == %d\n", a, b, cmp_dbl(a, b));
    printf("compare(%lf, %lf) == %d\n", b, b, cmp_dbl(b, a));
    printf("compare(%.7lf, %.7lf) == %d\n", pi_1, pi_2, cmp_dbl(pi_1, pi_2));
    printf("compare(%.7lf, %.7lf) == %d\n", pi_2, pi_1, cmp_dbl(pi_2, pi_1));*/

    // Activity 7 - implement set_index_of
    /*test_sorted_set_index_of();*/

    /*// Activity 8 - Time complexity of binary search
    // Create a set with 16 elements
    const size_t sizes[] = {16, 32, 54, 128, 256, 1000, 4000, 10000, 1048576};
    const size_t num_sizes = sizeof(sizes) / sizeof(sizes[0]);

    for (size_t i = 0; i < num_sizes; i++) {
        size_t set_size = sizes[i];

        // Create a set and fill it with values
        set_t* set = set_create(set_size, cmp_dbl);
        for (size_t j = 0; j < set_size; j++) {
            set->data[j] = j * 2.0;
            set->count++;
        }

        // Test binary search comparisons
        g_comparisons = 0; // Reset the global comparisons count
        set_index_of(set, -1.0); // Search for a value not present
        printf("Set Size: %zu, Comparisons: %zu\n", set_size, g_comparisons);

        // Destroy the set to free memory
        set_destroy(set);
*/
    // Activity 9 - Finalize the set
    test_sorted_set_contains();
    test_sorted_set_add();
    test_sorted_set_remove();






    return 0;
}
