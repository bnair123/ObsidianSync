//
// Created by rgr24 on 21/03/2023.
//

#ifndef SETS_TEST_SET_H
#define SETS_TEST_SET_H

void test_sorted_set_add(void);
void test_sorted_set_remove(void);
void test_sorted_set_contains(void);
void test_sorted_set_index_of(void);

#endif //SETS_TEST_SET_H
