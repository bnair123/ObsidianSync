//
// Created by rgr24 on 21/03/2023.
//
#include <malloc.h>
#include "set.h"

size_t g_comparisons = 0;

size_t set_index_of(const set_t *set, double value) {
    size_t lo = 0;
    size_t hi = set->count;


    while (lo < hi) {
        size_t mid = (lo + hi) / 2;

        int cmp_result = set->cmp_fun(set->data[mid], value);
        g_comparisons++;

        if (cmp_result == 0) {
            return mid;  // Value found at index mid
        } else if (cmp_result < 0) {
            lo = mid + 1;  // Value is in the right half
        } else {
            hi = mid;  // Value is in the left half
        }
    }

    return lo;  // Value not found, return the insertion point
}

void set_add(set_t * set, double value) {
    size_t index = set_index_of(set, value);

    if (index >= set->count || set->cmp_fun(set->data[index], value) != 0) {
        if (!ensure_capacity(set)) return;

        // Shift elements to the right to make space for the new value
        for (size_t i = set->count; i > index; i--) {
            set->data[i] = set->data[i - 1];
        }

        set->data[index] = value;
        set->count++;
    }
}

void set_remove(set_t * set, double value) {
    size_t index = set_index_of(set, value);

    if (index < set->count && set->cmp_fun(set->data[index], value) == 0) {
        // Shift elements to the left to remove the value
        for (size_t i = index; i < set->count - 1; i++) {
            set->data[i] = set->data[i + 1];
        }

        set->count--;
    }
}

bool set_contains(const set_t * set, double value) {
    if (set->count == 0) {
        return false;
    }
    size_t index = set_index_of(set, value);

    // If the index is not -1, then the value is in the set.
    return (index < set->count && set->cmp_fun(set->data[index], value) == 0);
}

set_t * set_create(size_t init_cap, compare_fun_t cmp_fun) {
    return set_init((set_t*) malloc(sizeof(set_t)), init_cap, cmp_fun);
}

set_t * set_init(set_t * set, size_t init_cap, compare_fun_t cmp_fun) {
    if (set != NULL) {
        set->cmp_fun = cmp_fun;
        set->data = (double*) malloc(sizeof(double) * init_cap);
        set->count = 0;
        set->capacity = set->data != NULL ? init_cap : 0;
    }
    return set;
}

